import { NextRequest, NextResponse } from 'next/server';
import { sendEmail, updateTestStatus, getTestEmailTemplate } from '@/lib/email';

// POST - Send test email
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { to } = body;

    if (!to || !to.includes('@')) {
      return NextResponse.json(
        { error: 'Adresse email invalide' },
        { status: 400 }
      );
    }

    const template = getTestEmailTemplate();
    
    const result = await sendEmail({
      to,
      subject: 'QRBag - Email de test',
      html: template.html,
      text: template.text,
      type: 'test',
    });

    // Update test status
    await updateTestStatus(result.success, result.error);

    if (result.success) {
      return NextResponse.json({ 
        success: true, 
        message: 'Email de test envoyé avec succès' 
      });
    } else {
      return NextResponse.json({ 
        success: false, 
        error: result.error || 'Erreur lors de l\'envoi de l\'email' 
      });
    }
  } catch (error) {
    console.error('Error sending test email:', error);
    return NextResponse.json(
      { error: 'Erreur lors de l\'envoi de l\'email de test' },
      { status: 500 }
    );
  }
}
